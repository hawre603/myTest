-- phpMyAdmin SQL Dump
-- version 4.0.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 07, 2014 at 02:25 PM
-- Server version: 5.5.33
-- PHP Version: 5.5.3

--
-- 7-may
--
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `musuemdata`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin1Guide2014031712474493`
--

CREATE TABLE `admin1Guide2014031712474493` (
  `date` varchar(25) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `postcode` varchar(15) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `submission` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin1Guide2014031712474493`
--

INSERT INTO `admin1Guide2014031712474493` (`date`, `age`, `postcode`, `email`, `submission`) VALUES
('15:07 17/03/2014', 27, 'le2 0fz', NULL, 'hawreGuide2014031701022272075550'),
('14:41 20/03/2014', 0, '', NULL, 'hawreGuide2014031701022272411327'),
('14:18 20/04/2014', 88, 'le2 0fz', NULL, 'admin1Guide201403171247449318015'),
('14:30 20/04/2014', 22, '00442', NULL, 'admin1Guide2014031712474493301042'),
('14:30 20/04/2014', 22, '00442', NULL, 'admin1Guide2014031712474493301150'),
('14:30 20/04/2014', 22, '00442', NULL, 'admin1Guide2014031712474493301252'),
('14:30 20/04/2014', 22, '00442', NULL, 'admin1Guide2014031712474493301236'),
('14:30 20/04/2014', 22, '00442', NULL, 'admin1Guide2014031712474493301277'),
('14:30 20/04/2014', 22, '00442', NULL, 'admin1Guide2014031712474493301274'),
('14:30 20/04/2014', 22, '00442', NULL, 'admin1Guide2014031712474493301475'),
('14:30 20/04/2014', 22, '00442', NULL, 'admin1Guide2014031712474493301498'),
('14:30 20/04/2014', 22, '00442', NULL, 'admin1Guide2014031712474493301520'),
('14:30 20/04/2014', 22, '00442', NULL, 'admin1Guide2014031712474493301564'),
('14:30 20/04/2014', 22, '00442', NULL, 'admin1Guide2014031712474493301574'),
('14:30 20/04/2014', 22, '00442', NULL, 'admin1Guide2014031712474493301559'),
('14:30 20/04/2014', 22, '00442', NULL, 'admin1Guide2014031712474493301652'),
('14:30 20/04/2014', 22, '00442', NULL, 'admin1Guide2014031712474493301657'),
('14:30 20/04/2014', 22, '00442', NULL, 'admin1Guide2014031712474493301645'),
('14:30 20/04/2014', 22, '00442', NULL, 'admin1Guide2014031712474493301659'),
('14:30 20/04/2014', 33, 'le2 0fz', NULL, 'admin1Guide2014031712474493304128'),
('14:30 20/04/2014', 33, 'le2 0fz', NULL, 'admin1Guide2014031712474493305343');

-- --------------------------------------------------------

--
-- Table structure for table `generated_qrcode`
--

CREATE TABLE `generated_qrcode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(60) DEFAULT NULL,
  `guide_name` varchar(60) NOT NULL,
  `file_path` varchar(200) NOT NULL,
  `generated_by` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `generated_qrcode`
--

INSERT INTO `generated_qrcode` (`id`, `page_title`, `guide_name`, `file_path`, `generated_by`) VALUES
(1, 'Test', 'hawreGuide2014030516055091', '/Applications/MAMP/htdocs/MuseumTest/admin/QRcode/QRImages/h', 'hawre');

-- --------------------------------------------------------

--
-- Table structure for table `guides`
--

CREATE TABLE `guides` (
  `by` varchar(20) NOT NULL,
  `title` text NOT NULL,
  `name` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `guides`
--

INSERT INTO `guides` (`by`, `title`, `name`, `date`, `active`) VALUES
('hawre', 'Open25 for reail test', 'admin1Guide2014031712474493', '2014-03-14', 1),
('', 'TestMe', 'Guide20140314192349100', '2014-03-14', 1),
('hawre', 'TestXML', 'hawreGuide2014030516045927', '2014-03-05', 1),
('hawre', 'Test', 'hawreGuide2014030516055091', '2014-03-05', 1),
('hawre', 'TestMe', 'hawreGuide2014030516131719', '2014-03-05', 1),
('hawre', 'Open25Guide', 'hawreGuide2014031701022272', '2014-03-17', 1),
('hawre', 'Test Navbar', 'hawreGuide201404021826597', '2014-04-02', 1),
('hawre', 'test nav', 'hawreGuide2014040218311422', '2014-04-02', 1),
('hawre', 'test nav2', 'hawreGuide2014040218323997', '2014-04-02', 1),
('hawre', 'test navebarrr', 'hawreGuide2014040219133988', '2014-04-02', 1),
('hawre', 'hi test', 'hawreGuide2014040220074059', '2014-04-02', 1),
('hawre', 'Test Video', 'hawreGuide2014040302330432', '2014-04-03', 1),
('mmsz', 'guide 1', 'mmszGuide2013091614452031', '2013-09-16', 1),
('msz', 'my guide', 'mszGuide2013091614370980', '2013-09-16', 0),
('newuser', 'My Local Guide', 'newuserGuide2014030423492855', '2014-03-04', 1),
('newuser', 'Local Test', 'newuserGuide201403042351061', '2014-03-04', 1);

-- --------------------------------------------------------

--
-- Table structure for table `hawreGuide201404021826597`
--

CREATE TABLE `hawreGuide201404021826597` (
  `date` varchar(25) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `postcode` varchar(15) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `submission` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hawreGuide2014030516045927`
--

CREATE TABLE `hawreGuide2014030516045927` (
  `date` varchar(25) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `postcode` varchar(15) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `submission` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hawreGuide2014030516055091`
--

CREATE TABLE `hawreGuide2014030516055091` (
  `date` varchar(25) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `postcode` varchar(15) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `submission` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hawreGuide2014030516131719`
--

CREATE TABLE `hawreGuide2014030516131719` (
  `date` varchar(25) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `postcode` varchar(15) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `submission` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hawreGuide2014031701022272`
--

CREATE TABLE `hawreGuide2014031701022272` (
  `date` varchar(25) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `postcode` varchar(15) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `submission` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hawreGuide2014031701022272`
--

INSERT INTO `hawreGuide2014031701022272` (`date`, `age`, `postcode`, `email`, `submission`) VALUES
('15:07 17/03/2014', 27, 'le2 0fz', NULL, 'hawreGuide2014031701022272075550'),
('14:41 20/03/2014', 0, '', NULL, 'hawreGuide2014031701022272411327'),
('13:30 20/04/2014', 0, '', NULL, 'hawreGuide2014031701022272304062'),
('13:38 20/04/2014', 0, '', NULL, 'hawreGuide2014031701022272385324'),
('14:14 20/04/2014', 0, '', NULL, 'hawreGuide2014031701022272144752'),
('14:15 20/04/2014', 55, 'le2 0fz', NULL, 'hawreGuide2014031701022272153817'),
('18:01 29/04/2014', 55, 'ffffff', NULL, 'hawreGuide2014031701022272010877'),
('18:01 29/04/2014', 55, 'ffffff', NULL, 'hawreGuide2014031701022272011024'),
('18:01 29/04/2014', 55, 'ffffff', NULL, 'hawreGuide2014031701022272011255'),
('18:01 29/04/2014', 55, 'ffffff', NULL, 'hawreGuide20140317010222720113100'),
('18:01 29/04/2014', 55, 'ffffff', NULL, 'hawreGuide2014031701022272011314'),
('18:01 29/04/2014', 55, 'ffffff', NULL, 'hawreGuide2014031701022272011321'),
('18:01 29/04/2014', 55, 'ffffff', NULL, 'hawreGuide2014031701022272011319'),
('18:01 29/04/2014', 55, 'ffffff', NULL, 'hawreGuide2014031701022272011383'),
('18:01 29/04/2014', 55, 'ffffff', NULL, 'hawreGuide2014031701022272011428'),
('18:01 29/04/2014', 55, 'ffffff', NULL, 'hawreGuide2014031701022272011573'),
('18:01 29/04/2014', 55, 'ffffff', NULL, 'hawreGuide2014031701022272011537'),
('18:01 29/04/2014', 55, 'ffffff', NULL, 'hawreGuide201403170102227201156'),
('18:01 29/04/2014', 55, 'ffffff', NULL, 'hawreGuide2014031701022272011516');

-- --------------------------------------------------------

--
-- Table structure for table `hawreGuide2014040218311422`
--

CREATE TABLE `hawreGuide2014040218311422` (
  `date` varchar(25) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `postcode` varchar(15) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `submission` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hawreGuide2014040218323997`
--

CREATE TABLE `hawreGuide2014040218323997` (
  `date` varchar(25) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `postcode` varchar(15) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `submission` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hawreGuide2014040219133988`
--

CREATE TABLE `hawreGuide2014040219133988` (
  `date` varchar(25) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `postcode` varchar(15) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `submission` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hawreGuide2014040220074059`
--

CREATE TABLE `hawreGuide2014040220074059` (
  `date` varchar(25) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `postcode` varchar(15) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `submission` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hawreGuide2014040302330432`
--

CREATE TABLE `hawreGuide2014040302330432` (
  `date` varchar(25) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `postcode` varchar(15) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `submission` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(150) NOT NULL,
  `privilage` tinyint(1) NOT NULL,
  `name` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `username`, `password`, `privilage`, `name`) VALUES
(2, 'admin', '$2y$10$53a96/sBSA4RdT/ZNp4OcOPpV9TM12OklQPOcAQVfPudEwno2W4Dy', 1, 'admin'),
(3, 'hawre', '$2y$10$khGGpmu9e1dB/DYZzrII.eccd942Y0FlniFx2CpELBeoLK3cvTAxS', 1, 'hawre');

-- --------------------------------------------------------

--
-- Table structure for table `mmszguide2013091614452031`
--

CREATE TABLE `mmszguide2013091614452031` (
  `date` date NOT NULL,
  `age` int(3) NOT NULL,
  `postcode` varchar(15) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `submission` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mszguide2013091614370980`
--

CREATE TABLE `mszguide2013091614370980` (
  `date` varchar(25) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `postcode` varchar(15) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `submission` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `newuserGuide201403042351061`
--

CREATE TABLE `newuserGuide201403042351061` (
  `date` varchar(25) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `postcode` varchar(15) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `submission` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `newuserGuide2014030423492855`
--

CREATE TABLE `newuserGuide2014030423492855` (
  `date` varchar(25) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `postcode` varchar(15) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `submission` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_location`
--

CREATE TABLE `tbl_location` (
  `loc_id` int(10) NOT NULL AUTO_INCREMENT,
  `loc_name` varchar(60) NOT NULL,
  `guide_status` int(11) NOT NULL,
  `create_date` date NOT NULL,
  `created_by` varchar(50) NOT NULL,
  PRIMARY KEY (`loc_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_location`
--

INSERT INTO `tbl_location` (`loc_id`, `loc_name`, `guide_status`, `create_date`, `created_by`) VALUES
(3, 'New_Walk_Museum', 1, '2014-05-07', 'hawre');

-- --------------------------------------------------------

--
-- Table structure for table `TestLogin`
--

CREATE TABLE `TestLogin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` char(128) NOT NULL,
  `salt` char(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `uploadedmedia`
--

CREATE TABLE `uploadedmedia` (
  `name` varchar(100) NOT NULL,
  `title` text NOT NULL,
  `type` varchar(5) NOT NULL,
  `insert_by` varchar(20) NOT NULL,
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `uploadedmedia`
--

INSERT INTO `uploadedmedia` (`name`, `title`, `type`, `insert_by`) VALUES
('Jaguar Kills and Eats Crocodile.mp4', 'jaguar', 'video', 'hawre'),
('myw3schoolsimage.jpg', 'w3s', 'image', ''),
('Open 25 Wide Image.jpg', 'Open25', 'image', ''),
('pengion.jpg', 'Penguins', 'image', ''),
('Penguins.jpg', 'Penguins', 'image', ''),
('qrcode.20058656.png', 'QR Code', 'image', ''),
('Wildlife.mp4', 'wild life', 'video', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
